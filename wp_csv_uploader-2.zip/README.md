# Kaggle Like Plugin
This plugin lets your website turn into Kaggle.
Simple Submission csv and calculate score.

## supported metric
- accuracy

<img src="./ka2.JPG">
<img src="./ka3.JPG">